/*
 * stack.c
 */

#define N	8

static double stack[N];
static int top = -1;

void push(double x)
{
	stack[++top] = x;
}

double pop(void)
{
	return stack[top--];
}
