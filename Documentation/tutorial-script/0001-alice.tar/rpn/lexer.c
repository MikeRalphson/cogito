/*
 * lexer.c
 */

#include <stdio.h>
#include <ctype.h>

extern double val;

int getsym(void)
{
	int c;

	while (isspace(c = getchar()) && c != EOF)
		;

	if (isdigit(c)) {
		ungetc(c, stdin);
		scanf("%lf", &val);
		return '9';
	}
	else
		return c;
}
